# SGCUW
Trabajo grupal CulturaDigital

**Cada usuario que suba su avance a su branch y luego se hace un merge con todo en la rama descargar. La rama master es lo que se entrega, es decir, un merge definitivo**
